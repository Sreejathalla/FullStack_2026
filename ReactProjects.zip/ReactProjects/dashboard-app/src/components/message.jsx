function Message() {
  return (
    <div className="card">
      <h2>Message</h2>
      <p>This dashboard shows static course information using React components.</p>
    </div>
  );
}

export default Message;
