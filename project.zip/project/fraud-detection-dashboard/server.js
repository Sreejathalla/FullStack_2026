const express = require("express");
const bodyParser = require("body-parser");
const session = require("express-session");
const path = require("path");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
    secret: "fraudsecret",
    resave: false,
    saveUninitialized: true
}));

app.use(express.static("public"));

/* LOGIN PAGE */
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname,"views/login.html"));
});

/* LOGIN CHECK */
app.post("/login", (req,res)=>{

    const username = req.body.username;
    const password = req.body.password;

    if(username==="admin" && password==="1234"){
        req.session.user = username;
        res.redirect("/home");
    }
    else{
        res.send("Invalid Login");
    }

});

/* HOME */
app.get("/home",(req,res)=>{
res.sendFile(path.join(__dirname,"views/home.html"));
});

/* TRANSACTIONS */
app.get("/transactions",(req,res)=>{
res.sendFile(path.join(__dirname,"views/transactions.html"));
});

/* FRAUD */
app.get("/fraud",(req,res)=>{
res.sendFile(path.join(__dirname,"views/fraud.html"));
});

/* REPORTS */
app.get("/reports",(req,res)=>{
res.sendFile(path.join(__dirname,"views/reports.html"));
});

/* LOGOUT */
app.get("/logout",(req,res)=>{
req.session.destroy();
res.redirect("/");
});

app.listen(3000,()=>{
console.log("Server running on http://localhost:3000");
});